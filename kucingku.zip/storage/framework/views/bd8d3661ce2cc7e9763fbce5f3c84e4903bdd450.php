<?php $__env->startSection('content'); ?>
<!-- List Start -->
<div class="container pt-5">
    <div class="d-flex flex-column text-center mb-5">
        <h5 class="text-primary mb-3">Data Kucing</h5>
        <h1 class="m-0">List Kucing di KucingKu</h1>
    </div>
    <?php $__currentLoopData = $kucing->chunk(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row">
        <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4 mb-4">
            <div class="card mb-2 p-3">
                <img href="<?php echo e(route('main.kucing_selengkapnya',$cat->id)); ?>" class="card-img-top" style="width: 316px;height: 237px;" src="<?php echo e(asset('storage/kucing/'.$cat->image)); ?>" alt="">
                <div href="<?php echo e(route('main.kucing_selengkapnya',$cat->id)); ?>" class="card-body bg-secondary d-flex align-items-center p-0">
                    <h6 class="card-title text-white text-truncate m-0 ml-3"><?php echo e($cat->nama); ?> - <?php echo e($cat->ras); ?></h6>
                    <a href="<?php echo e(route('main.kucing_selengkapnya',$cat->id)); ?>" style="width: 45px; height: 45px;" ></a>
                </div>
                <div class="card-footer py-3 px-4" href="<?php echo e(route('main.kucing_selengkapnya')); ?>" >
                    <p class="m-0" ><?php echo e(substr($cat->deskripsi, 0,  150)); ?>...<a href="<?php echo e(route('main.kucing_selengkapnya',$cat->id)); ?>"> Selengkapnya</a></p>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12">
            <nav aria-label="Page navigation">
              <ul class="pagination justify-content-center mb-4">
                <?php echo $kucing->links(); ?>

              </ul>
            </nav>
        </div>
    </div>
</div>
<!-- List End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kucingku\resources\views/main/kucing-list.blade.php ENDPATH**/ ?>