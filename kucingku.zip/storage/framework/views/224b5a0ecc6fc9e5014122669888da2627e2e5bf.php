<?php $__env->startSection('content'); ?>
<!-- Detail Start -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8">
            <div class="d-flex flex-column text-left mb-4">
                <h5 class="text-primary mb-3">Detail Kucing</h5>
                <h1 class="mb-3"><?php echo e($kucing->nama); ?>-<?php echo e($kucing->ras); ?></h1>
            </div>

            <div class="mb-5">
                <img class="img-thumbnail mb-4 p-3" src="<?php echo e(asset('storage/kucing/'.$kucing->image)); ?>" alt="Image">
                <h6>Nama : <?php echo e($kucing->nama); ?> </h6>
                <h6>Ras : <?php echo e($kucing->ras); ?> </h6>
                <h6>Umur : <?php echo e($kucing->umur); ?> </h6>
                <h6>Berat : <?php echo e($kucing->berat); ?> kg </h6>
                <h6>Jenis Kelamin : <?php echo e($kucing->jenis_kelamin); ?> </h6>
                <p style="text-align: justify; white-space: pre-wrap;"><?php echo e($kucing->deskripsi); ?></p>
            </div>

            <div class="media bg-primary text-white mb-4 p-4 p-md-5">
                <img src="<?php echo e(asset('img/please.png')); ?>" alt="Image" class="mr-4 bg-primary" style="width:100px;">
                <div class="media-body">
                    <h5 class="mb-3">Tertarik Dengan Kucing Ini?</h5>
                    <p class="m-0">Ayo salurkan bantuan mu dengan ajukan adopsi :D</p>
                    <br>
                    <a href="<?php echo e(route('main.adopt')); ?>" class="btn btn-success"  id="sendMessageButton">Ajukan Adopsi</a>
                </div>
            </div>
        </div>
        </div>
    </div>
</div>
<!-- Detail End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kucingku\resources\views/main/kucing-selengkapnya.blade.php ENDPATH**/ ?>