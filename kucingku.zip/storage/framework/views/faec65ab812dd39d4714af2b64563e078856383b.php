<?php $__env->startSection('content'); ?>
<div class="container-fluid px-4">
    <h1 class="mt-4">Detail Data Adopter</h1>
    <ol class="breadcrumb mb-4">
        <li class="breadcrumb-item active">Adopter Details</li>
    </ol>
    <form enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div class="mb-3">
          <label for="exampleInputEmail1" class="form-label">Nama Adopter</label>
          <input type="text" class="form-control" id="nama" name="nama" aria-describedby="emailHelp" value="<?php echo e($adopter->nama); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Alamat</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->alamat); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">No KTP</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->no_ktp); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">No Handphone</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->no_hp); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Email</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->email); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Profesi</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->profesi); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Sosial Media</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->sosmed); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Nama Kucing yang diajukan</label>
            <input type="text" class="form-control" id="penulis" name="penulis" aria-describedby="emailHelp" value="<?php echo e($adopter->kucing_data->nama); ?>" disabled>
        </div>
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Foto</label><br>
            <img src= <?php echo e(asset('storage/kucing/'.$adopter->kucing_data->image)); ?> width="800px" height="500px">
        </div>
      </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kucingku\resources\views/admin/detail-adopter.blade.php ENDPATH**/ ?>