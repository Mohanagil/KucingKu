<?php $__env->startSection('content'); ?>
<!-- Detail Start -->
<div class="container py-5">
    <div class="row">
        <div class="col-lg-8">
            <div class="d-flex flex-column text-left mb-4">
                <h5 class="text-primary mb-3">Blog Detail</h5>
                <h1 class="mb-3"><?php echo e($blog->judul); ?></h1>
                <div class="d-index-flex mb-2">
                    <span class="mr-3"><i class="fa fa-user text-primary"></i> <?php echo e($blog->penulis); ?></span>
                    <span class="mr-3"><i class="fa fa-clock text-primary"></i> <?php echo e($blog->created_at); ?></span>
                </div>
            </div>

            <div class="mb-5">
                <img class="img-thumbnail mb-4 p-3" src="<?php echo e(asset('storage/blog/'.$blog->image)); ?>" alt="Image">
                <p style="text-align: justify; white-space: pre-wrap;"><?php echo e($blog->deskripsi); ?></p>
            </div>
        </div>
    </div>
</div>
<!-- Detail End -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kucingku\resources\views/main/blog-selengkapnya.blade.php ENDPATH**/ ?>