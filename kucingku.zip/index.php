<?php
header(‘Location: public/’);
?>
